<?php

$host="localhost";
$user="root";
$password="";
$dbase="vegauctions";
$link=mysqli_connect($host, $user, $password, $dbase);

?>