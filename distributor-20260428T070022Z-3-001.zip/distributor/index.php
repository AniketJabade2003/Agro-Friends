<?php session_start();
        if($_SESSION['id']==""){
            header("location:../");
        }
   ?>

<!DOCTYPE html>
<html>
<head>
<title>Next Gen Auctions</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- pignose css -->
<link href="../css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />


<!-- //pignose css -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="../js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- cart -->
	<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
	<script type="text/javascript" src="../js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
<script src="../js/jquery.easing.min.js"></script>
</head>
<body>
   
    
<!-- header -->
<div class="header-bot">
	<div class="container">
		<div class="col-md-3 header-left">
			<h1><a href="/veg/distributor"><img src="../images/logo3.jpg"></a></h1>
		</div>
	</div>
</div>
<!-- //header-bot -->
<!-- banner -->
<div class="ban-top">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li class="active menu__item menu__item--current"><a class="menu__link" href="index.php">Home<span class="sr-only">(current)</span></a></li>
                                        <li><a class="menu__link" href="addprod.php">New Product</a></li>
                                        <li><a class="menu__link" href="order.php">Bids</a></li>
                                        <li><a class="menu__link" href="completed.php">Completed</a></li>
                                        <li><a class="menu__link" href="logout.php">Logout</a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
	</div>
</div>
<!-- //banner-top -->
<Center>

    <div class="product-easy">
    <h3><span></span> </h3>
    
    <?php
        echo "<h1>Auctions Product List</h1>";
    ?>
        <table class="table">
            <tbody>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Type</th>
                <th>Category</th>
                <th>Packing</th>
                <th>Base Price</th>
                <th>Expired</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            </tbody>
        <?php
        include '../config/dbconnection.php';
        $query="select * from tblproducts where username='{$_SESSION['id']}' and paid<>'Y'";
        $result=mysqli_query($link,$query);
        while($row=  mysqli_fetch_assoc($result)){
         ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['type']; ?></td>
                <td><?php echo $row['brand']; ?></td>
                <td><?php echo $row['model']; ?></td>
                <td><?php echo $row['price']; ?></td>
                <?php if($row['confirmed']=='T'){?>
                <td>Expired</td>
                <?php }else{ ?>
                <td>-</td>
                <?php } ?>
                <td><a href="index.php?pid=<?php echo $row['id']; ?>">Edit</a></td>
                <td><a href="index.php?did=<?php echo $row['id']; ?>" onclick="return confirm('Do you really want to delete this product')">Delete</a></td>
            </tr>
        <?php
        
        }
        
    ?>
       </table>
        
        
    <?php
        if(isset($_GET['pid'])){
            echo "<h3>Edit</h3>";
        $query="select * from tblproducts where id='{$_GET['pid']}'";
        $result=mysqli_query($link,$query);
        $ros=mysqli_fetch_assoc($result);
        $dt=$ros['dtend'];
        ?>
                   <form name="f" method="post" action=""  enctype="multipart/form-data">
                        <div class="contact-form2">
                            <input type="text" placeholder="Product ID" name="id" readonly style="width:300px;" value="<?php echo $ros['id']; ?>"/><br/><br/>
                                <input type="text" placeholder="Product Name" name="name" autofocus required style="width:300px;"  value="<?php echo $ros['name']; ?>"/><br/><br/>
                                <Select placeholder="Product type" name="type" required style="width:300px;">
                                    <option><?php echo $ros['type']; ?></option>
                                    <option>Ready to Cook</option>
                                    <option>Cut Vegetables</option>
                                    <option>Regular Vegetables</option>
                                    <option>Other Equipment</option>
                                </select><br/><br/>
                                <input type="text" placeholder="Category" name="brand" required style="width:300px;" value="<?php echo $ros['brand']; ?>"/><br/><br/>
                                <input type="text" placeholder="Packing Type" name="model" required style="width:300px;" value="<?php echo $ros['model']; ?>"/><br/><br/>
                                <input type="text" placeholder="Base Price" name="price" pattern="[0-9]+$" required style="width:300px;" value="<?php echo $ros['price']; ?>"/><br/><br/>
                                <textarea placeholder="Product Description" name="description" required style="width:300px;"><?php echo $ros['description']; ?></textarea><br/><br/>
                                <input type="submit" value="Update Data" class="item_add hvr-outline-out button2" name="save"/>
                        </div><br/><br/>
                </form>
        <?php
        }
        
        if(isset($_REQUEST['save'])){
            $query="update tblproducts set name='{$_POST['name']}',type='{$_POST['type']}',brand='{$_POST['brand']}',model='{$_POST['model']}',price='{$_POST['price']}',description='{$_POST['description']}' where id='{$_POST['id']}'";
            $result=mysqli_query($link,$query);
            if(mysqli_affected_rows($link)>0){
                echo "<script> alert('Product details updated');
                      window.location.href='index.php' </script>";
            }else{
                echo "<script> alert('Product details cannot be updated at this time'); </script>";
            }
        }
        
        if(isset($_GET['did'])){
            $query="delete from tblproducts where id='{$_GET['did']}'";
            $result=mysqli_query($link,$query);
            echo "<script> window.location.href='index.php' </script>";
        }
    ?>
       </table>
    </div>
<!-- content-bottom -->
</body>
</html>