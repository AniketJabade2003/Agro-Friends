<?php session_start();
        if($_SESSION['id']==""){
            header("location:../");
        }
?>
<!DOCTYPE html>
<html>
<head>
<title>Next Gen Auctions</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- pignose css -->
<link href="../css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />

<!-- //pignose css -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="../js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- cart -->
	<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
	<script type="text/javascript" src="../js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
<script src="../js/jquery.easing.min.js"></script>
</head>
<body>
    
<!-- header -->
<div class="header-bot">
	<div class="container">
		<div class="col-md-3 header-left">
			<h1><a href="/veg/distributor"><img src="../images/logo3.jpg"></a></h1>
		</div>
	</div>
</div>
<!-- //header-bot -->
<!-- banner -->
<div class="ban-top">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li><a class="menu__link" href="index.php">Home<span class="sr-only">(current)</span></a></li>
                                        <li><a class="menu__link" href="addprod.php">New Product</a></li>
                                        <li><a class="menu__link" href="order.php">Bids</a></li>
                                        <li class="active menu__item menu__item--current"><a class="menu__link" href="completed.php">Completed</a></li>
                                        <li><a class="menu__link" href="logout.php">Logout</a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
	</div>
</div>
<!-- //banner-top -->
<Center>

    <div class="product-easy">
                    <h3><span></span> </h3>
    <?php
            echo "<h1>Payment Processed</h1><br/>";
            ?>
        <table class="table">
            <tbody>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Type</th>
                <th>Category</th>
                <th>Packing</th>
                <th>Base Price</th>
                <th>Auction Price</th>
                <th>Customer</th>
                <th>Address</th>
                <th>Mobile</th>
            </tr>
            </tbody>
        <?php
        include '../config/dbconnection.php';
        $query="select * from tblproducts where username='{$_SESSION['id']}' and confirmed='Y' and paid='Y'";
        $result=mysqli_query($link,$query);
        while($row=  mysqli_fetch_assoc($result)){
         ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['type']; ?></td>
                <td><?php echo $row['brand']; ?></td>
                <td><?php echo $row['model']; ?></td>
                <td><?php echo $row['price']; ?></td>
                <td><?php echo $row['current']; ?></td>
                <td><?php echo $row['customer']; ?></td> 
                <td><?php echo $row['address']; ?></td> 
                <td><?php echo $row['mobile']; ?></td> 
            </tr>
        <?php
        
        }
        
    ?>
       </table>
        
       
        <?php
        if(isset($_GET['pid'])){
            $query="update tblproducts set confirmed='Y' where id='{$_GET['pid']}'";
            $result=mysqli_query($link,$query);
            if(mysqli_affected_rows($link)>0){
                echo "<script> alert('Confirmed Successful'); "
                . "window.location.href='?'; </script>";
            }else{
                echo "<script> alert('Please try later'); </script>";
            }
        }
    ?>
       </table>
    </div>
<!-- content-bottom -->
</body>
</html>