<!DOCTYPE html>
<html>
<head>
<title>Next Gen Auctions</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- pignose css -->
<link href="../css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />


<!-- //pignose css -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="../js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- cart -->
	<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
	<script type="text/javascript" src="../js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
<script src="../js/jquery.easing.min.js"></script>
</head>
<body>
   <?php
        session_start();
        if($_SESSION['id']==""){
            header("location:/veg/admin");
        }
   ?>
    
<!-- header -->
<div class="header-bot">
	<div class="container">
		<div class="col-md-3 header-left">
			<h1><a href="/veg/admin"><img src="../images/logo3.jpg"></a></h1>
		</div>
	</div>
</div>
<!-- //header-bot -->
<!-- banner -->
<div class="ban-top">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li class="active menu__item menu__item--current"><a class="menu__link" href="home.php">Home<span class="sr-only">(current)</span></a></li>
                                        <li><a class="menu__link" href="auctions.php">Auctions</a></li>
                                        <li><a class="menu__link" href="logout.php">Logout</a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
	</div>
</div>
<!-- //banner-top -->
<Center>
<div class="new_arrivals">
	<div class="container">
		<h3><span>These are new request form the Users</span> </h3>
		<div class="new_grids"> 
			<div class="col-md-4 new-gd-left">
				<img src="images/wed1.jpg" alt=" " />
				<div class="wed-brand simpleCart_shelfItem">
					<h4>Farmers Request</h4>
					<h5>Total Requests</h5>
                                        <?php
                                            include '../config/dbconnection.php';
                                            $query="Select count(*) as cnt from tbldistributor where confirmed='No'";
                                            $result=mysqli_query($link,$query);
                                            $row= mysqli_fetch_assoc($result);
                                        ?>
					<p> <span class="item_price"><?php echo $row['cnt'] ?></span><a class="item_add hvr-outline-out button2" href="home.php?type=dist">View Details</a></p>
				</div>
			</div>
<!--                    <div class="col-md-4 new-gd-left">
				<img src="images/wed1.jpg" alt=" " />
				<div class="wed-brand simpleCart_shelfItem">
					<h4>Customer Request</h4>
					<h5>Total Requests</h5>
                                        <?php
//                                            include '../config/dbconnection.php';
//                                            $query="Select count(*) as cnt from tblcustomer where confirmed='No'";
//                                            $result=mysqli_query($link,$query);
//                                            $row= mysqli_fetch_assoc($result);
                                        ?>
					<p> <span class="item_price"><?php //echo $row['cnt'] ?></span><a class="item_add hvr-outline-out button2" href="home.php?type1=cust">View Details</a></p>
				</div>
			</div>-->
		</div>
	</div>    
</div>
    <div class="product-easy"><br/><br/>
    <?php
        if(isset($_GET['type'])=="dist"){
            echo "<h1>Farmers Requests </h1>";
 ?>
        
        <table class="table table-bordered table-striped">
            <tbody>
            <tr>
                <th>Request ID</th>
                <th>Farmer Name</th>
                <th>Mobile</th>
                <th>Address</th>
                <th>Allow</th>
            </tr>
            </tbody>
        <?php
        $query="select * from tbldistributor where confirmed='No'";
        $result=mysqli_query($link,$query);
        while($row=  mysqli_fetch_assoc($result)){
        ?>
                 <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['mobile']; ?></td>
                    <td><?php echo $row['address']; ?></td>
                    <td><a href="home.php?did=<?php echo $row['id']; ?>">Allow</a></td>
                </tr>
            <?php
            }
        }
        
        
        if(isset($_GET['did'])){
            $query="update tbldistributor set confirmed='Yes' where id='{$_GET['did']}'";
            $result=mysqli_query($link,$query);
            echo "<script> window.location.href='home.php?type=dist' </script>";
        }
    ?>
       </table>
        
        
    <?php
        if(isset($_GET['type1'])=="cust"){
            echo "<h1>Customer Requests</h1>";
            ?>
        <table class="table">
            <tbody>
            <tr>
                <th>Request ID</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Address</th>
                <th>Organization</th>
                <th>Registration Name</th>
                <th>Registration Number</th>
                <th>Allow</th>
            </tr></tbody>
        <?php
        $query="select * from tblcustomer where confirmed='No'";
        $result=mysqli_query($link,$query);
        while($row=  mysqli_fetch_assoc($result)){
        ?>
             <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['mobile']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><?php echo $row['type']; ?></td>
                <td><?php echo $row['regname']; ?></td>
                <td><?php echo $row['regno']; ?></td>
                <td><a href="home.php?cid=<?php echo $row['id']; ?>">Allow</a></td>
            </tr>
        <?php
        
        }
        }
        
        if(isset($_GET['cid'])){
            $query="update tblcustomer set confirmed='Yes' where id='{$_GET['cid']}'";
            $result=mysqli_query($link,$query);
            echo "<script> window.location.href='home.php?type1=cust' </script>";
        }
    ?>
       </table>
    </div>
<!-- content-bottom -->
</body>
</html>