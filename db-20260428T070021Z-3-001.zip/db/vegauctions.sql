-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2025 at 01:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vegauctions`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbid`
--

CREATE TABLE `tblbid` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `bid` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblbid`
--

INSERT INTO `tblbid` (`id`, `username`, `bid`) VALUES
(1, 'xyz', 2100),
(3, 'xyz', 18800),
(2, 'abc', 6000),
(1, 'abc', 22500),
(2, 'xyz', 6300),
(6, 'aniket', 2200);

-- --------------------------------------------------------

--
-- Table structure for table `tblcard`
--

CREATE TABLE `tblcard` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `cardno` varchar(16) NOT NULL,
  `mm` int(11) NOT NULL,
  `yy` int(11) NOT NULL,
  `cvv` int(11) NOT NULL,
  `amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcard`
--

INSERT INTO `tblcard` (`id`, `name`, `cardno`, `mm`, `yy`, `cvv`, `amount`) VALUES
(1, 'abc', '1111222233334444', 10, 25, 789, 25000);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

CREATE TABLE `tblcomments` (
  `id` int(11) NOT NULL,
  `prodid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `seller` varchar(50) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcomments`
--

INSERT INTO `tblcomments` (`id`, `prodid`, `username`, `seller`, `comment`) VALUES
(1, 1, 'xyz', 'aaa', 'Good flowers'),
(2, 3, 'xyz', 'bbb', 'Very sweet and tasty potatoes ');

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

CREATE TABLE `tblcustomer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmed` varchar(10) NOT NULL DEFAULT 'Yes'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcustomer`
--

INSERT INTO `tblcustomer` (`id`, `name`, `mobile`, `email`, `address`, `username`, `password`, `confirmed`) VALUES
(1, 'abc', '8523691407', 'bhushan.dcs@gmail.com', 'bgm', 'abc', 'abc', 'Yes'),
(2, 'xyz', '9880917783', 'bhushan.dcs@gmail.com', 'bgm', 'xyz', 'xyz', 'Yes'),
(3, 'Aniket', '9880917783', 'aniket@gmail.com', 'Bgm', 'aniket', 'aniket', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbldistributor`
--

CREATE TABLE `tbldistributor` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmed` varchar(10) NOT NULL DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbldistributor`
--

INSERT INTO `tbldistributor` (`id`, `name`, `mobile`, `email`, `address`, `username`, `password`, `confirmed`) VALUES
(1, 'AAA', '9876543210', 'aaa@gmail.com', 'Bgm', 'aaa', 'aaa', 'Yes'),
(2, 'bbb', '8523691407', 'bbb@gmail.com', 'Bgm', 'bbb', 'bbb', 'Yes'),
(3, 'Akash', '8523691407', 'akash@gmail.com', 'Bgm', 'akash', 'akash', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbllogin`
--

CREATE TABLE `tbllogin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbllogin`
--

INSERT INTO `tbllogin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

CREATE TABLE `tblproducts` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `description` varchar(200) NOT NULL,
  `filename0` varchar(50) NOT NULL,
  `dtstart` datetime NOT NULL,
  `dtend` datetime NOT NULL,
  `username` varchar(50) NOT NULL,
  `customer` varchar(50) NOT NULL,
  `current` int(11) NOT NULL DEFAULT 0,
  `confirmed` char(1) NOT NULL DEFAULT 'N',
  `paid` varchar(1) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`id`, `name`, `type`, `brand`, `model`, `price`, `description`, `filename0`, `dtstart`, `dtend`, `username`, `customer`, `current`, `confirmed`, `paid`) VALUES
(1, 'Lily', 'Flowers', 'White', '1 Box', 20000, 'Nice Fragrance', '1listing_2.jpg', '2025-03-28 04:17:00', '2025-03-31 01:01:00', 'aaa', 'abc', 22500, 'Y', 'Y'),
(2, 'Apple', 'Fruits', 'Type 2 Category', '10 Box', 5000, 'Red apple from apple garden', '2listing_9.jpg', '2025-03-28 04:19:00', '2025-03-31 14:02:00', 'aaa', 'xyz', 6300, 'T', 'N'),
(3, 'Potato', 'Vegetables', 'Red Mud', '100 Kg', 18500, 'Grown in red mud\r\nGood quality\r\nProper color', '3listing_5.jpg', '2025-03-28 04:21:00', '2025-03-31 15:01:00', 'bbb', 'xyz', 18800, 'Y', 'Y'),
(4, 'Red Rose', 'Flowers', 'Button Rose', '100 Nos', 650, 'Button rose with nice furnished pot ', '4listing_7.jpg', '2025-03-28 04:26:00', '2025-03-31 13:01:00', 'bbb', '', 0, 'T', 'N'),
(5, 'Cabbage', 'Vegetables', 'Cat A', '1 Bundle', 1000, 'Green cabbage\r\nNon-hybrid', '5listing_3.jpg', '2025-04-11 04:20:00', '2025-04-11 16:30:00', 'akash', '', 0, 'T', 'N'),
(6, 'Apple', 'Fruits', 'Kashmir Apples', '100 Nos', 2000, 'Red apple', '6listing_8.jpg', '2025-04-11 04:23:00', '2025-04-12 10:00:00', 'akash', 'aniket', 2200, 'Y', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tmpcart`
--

CREATE TABLE `tmpcart` (
  `id` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcard`
--
ALTER TABLE `tblcard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomments`
--
ALTER TABLE `tblcomments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldistributor`
--
ALTER TABLE `tbldistributor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcard`
--
ALTER TABLE `tblcard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcomments`
--
ALTER TABLE `tblcomments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbldistributor`
--
ALTER TABLE `tbldistributor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
